# hercules > 2024-08-06 3:10am
https://universe.roboflow.com/danielrtrindade1-gmail-com/hercules

Provided by a Roboflow user
License: CC BY 4.0

